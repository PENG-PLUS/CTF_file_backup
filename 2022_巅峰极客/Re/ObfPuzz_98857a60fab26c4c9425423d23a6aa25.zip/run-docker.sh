docker build -t ctf_obfpuzz .
docker run --rm -it -p 1447:1447 ctf_obfpuzz
