<?php
echo 'Where is flag?<br>';

$token = md5($_GET['flag']);

function verify($pos) {
    $target = "b2723de888a48cad92c4";
    if(strlen($_GET['flag']) < $pos || $pos >= 500)
        return 0; 
    
    $GLOBALS['token'] = md5($GLOBALS['token'] . $_GET['flag'][$pos]);

    var_dump(ord($_GET['flag'][$pos]));

	if(substr($GLOBALS['token'], 0, strlen($target)) === $target) {
        return 1;
    } else {
		return verify($pos + 1);
	}
}

function oops() {
	echo "oops! token: ".$GLOBALS['token'];
}

function win() {
	echo "<br><br>win! your flag is: flag{".md5(md5($_GET['flag'])) . "}";
}

if (verify(0)) {
	win();
} else {
	oops();
}

?>