g = 916143391925527262831875920931
p = 11629419588729710248789180926208072549658261770997088964503843186890228609814366773219056811420217048972200345700258846936553626057834496

from Crypto.Cipher import AES
from hashlib import sha256
def gen_pub(x,g,p):
    return pow(g,x,p)

def gen_sharekey(A,b):
    share = pow(A,b,p)
    sharekey =  sha256(str(share)).hexdigest()[:16]
    return sharekey

def pad(msg):
    l = 16-(len(msg)%16)
    return  msg+'\x00'*l
def encrypt(sharekey,msg):
    msg = pad(msg)
    aes = AES.new(key,AES.MODE_ECB)
    return aes.encrypt(msg)

....
....
....
