var crypto = require('crypto');

class Utils {

    static checkSignIn(req, res, next) {
        if (req.session.userID === undefined || req.session.userID === null) {
            return res.redirect('/login')
        }
        next();
    };

    // useless code...
    static filter(str){
        if(/union|and|&|\|| |,|regexp|limit|sleep|lpad|rpad|if|ascii|order|substr|\'|>|<|min|left|like|=|\^|update/.test(str)) {
            return false;
        }
    };

    static md5(str) {
        var md5sum = crypto.createHash('md5');
        md5sum.update(str);
        str = md5sum.digest('hex');
        return str;
    };

    static extend(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i]
            
            for (var key in source) {
                if (key === '__proto__') {
                    return;
                }
                if (hasOwnProperty.call(source, key)) {
                    if (key in source && key in target) {
                        Utils.extend(target[key], source[key])
                    } else {
                        target[key] = source[key]
                    }
                }
            }
        }
        return target
    }
}

module.exports = Utils;
