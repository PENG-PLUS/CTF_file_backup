var createError = require('http-errors');
var express = require('express');
var path = require('path');
var session = require('express-session');
var randomize = require('randomatic');
var logger = require('morgan');
var mysql = require("mysql");
var nodemailer = require('nodemailer');
var utils = require('./utils');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'twig');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// start session
app.use(session({
  name: 'thejs.session',
  secret: randomize('Ye0h', 16),
  resave: true,
  saveUninitialized: true
}))

// init database
var connection  = mysql.createConnection({
  host:'localhost',
  user:'root',
  password:'123456',
  database:'ctf'
});

// init nodemailer
const config = {
  service: "ctf",
  auth: {
    user: 'admin@ctfer.com',
    pass: 'xxxxxxxxxxxxxxxxxxxxxx'
  }
}

app.get('/', utils.checkSignIn, function(req, res, next) {
  return res.redirect('/home');
});

app.all('/home', utils.checkSignIn, function(req, res, next) {
  var userInfo = {
    "username": req.session.userID,
    "email": req.session.email
  }
  if(req.method == 'GET') {
    return res.render('home', {"username": req.session.userID, "userInfo": userInfo});
  }
  
  if(req.method == 'POST') {
    try {
      utils.extend(userInfo, req.body);
      return res.render('home', {"username": req.session.userID, "userInfo": userInfo});
    }catch(err) {
      console.log(err.message)
      var transporter = nodemailer.createTransport(config);
      transporter.sendMail({
        from: 'admin@ctfer.com',
        to: req.session.email,
        subject: 'Something went wrong.',
        text: err.message
      }, function(err, info) {
        if(err) {
          return console.log(err);
        }
        transporter.close();
      })
    }
  }
  res.send()
  //res.render('index', { title: 'Express' });
});


app.all('/register', function(req, res, next) {
  if(req.method == 'GET') {
    return res.render('register', { title: 'Express' });
  }

  if(req.method == "POST") {
    var username = req.body.username;
    var password = req.body.password;
    var email = req.body.email;

    if (username !== undefined && password !== undefined) {
      var querySql = "select * from users where username = ?";
      connection.query(querySql, [username], function(err, result) {
        if(err) {
          console.log(err.message);
          return res.send("<script>alert('Error!');window.location.href='/register'</script>");

        }

        result = JSON.parse(JSON.stringify(result))[0];
        if(result && result.username !== undefined) {
          return res.send("<script>alert('User already exists.');window.location.href='/register'</script>");

        }else {

          var insertSql = "insert into users (`username`, `password`, `email`) value (?, ?, ?)";
          connection.query(insertSql, [username, utils.md5(password), email], function(err, result) {
            if(err) {
              console.log(err.message);
              return res.send("<script>alert('Error!');window.location.href='/register'</script>");

            }
          return res.send("<script>alert('Register successed');window.location.href='/login'</script>");

          });

        }
      });
    }
  }
});


app.all('/login', function(req, res, next) {
  if(req.method == 'GET') {
    return res.render('login', { title: 'Express' });
  }

  if(req.method == "POST") {
    var username = req.body.username;
    var password = req.body.password;

    var querySql = "select * from users where username = ? and password = ?";
    connection.query(querySql, [username, utils.md5(password)], function(err, result) {
      if(err) {
        console.log(err.message);
        return res.end("<script>alert('Error!');window.location.href='/login'</script>");
      }
      result = JSON.parse(JSON.stringify(result))[0];
      if(result && result.username === username && result.password === utils.md5(password)) {
        req.session.userID = req.body.username;
        req.session.email = result.email;
        return res.end("<script>alert('Login successed.');window.location.href='/'</script>");
      }
      return res.end("<script>alert('Login failed.');window.location.href='/'</script>");
    });
  }
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

var server = app.listen(8000, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("http://%s:%s", host, port)
});
