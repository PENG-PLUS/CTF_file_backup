<html>
<body>
    <style>
        img
        {
            width: 160px;
            height: 160px;
        }
    </style>

    <center>
        <h2>Welcome to game02: Tiger-Stick-Rooster!</h2><h3>(Stick Win Tiger, Tiger Win Rooster, Rooster Win Worm, Worm Win Stick)</h3><br><br>

        <?php
            error_reporting(0);

            $win = 0;
            if (isset($_COOKIE["win"]))
            {
                $win = addslashes($_COOKIE["win"]);
            }

            if (isset($_GET["oper"]) and isset($_GET["value"]))
            {
                $oper = addslashes($_GET["oper"]);
                $value = addslashes($_GET["value"]);

                $white_str = array("S", "T", "R", "W", "game01", "game02", "game03", "game04", "game05");
                if (($oper == "play" or $oper = "reward") and in_array($value, $white_str))
                {
                    $ch = curl_init();
                    $url = "http://127.0.0.1:8080/cgi-bin/game02.cgi?oper=".$oper."&value=".$value;
                    
                    $cookie = "win=".$win.";";
                    $key = "";
                    if (isset($_COOKIE["key"]))
                    {
                        $key = addslashes($_COOKIE["key"]);
                        $cookie = $cookie."key=".$key;
                    }

                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    $output = curl_exec($ch);
                    curl_close($ch);

                    if ($output == "win")
                    {
                        echo "<h3>You win this one!</h3>";

                        $win = $win + 1;
                        $key = md5($key.$_GET["value"]);

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    elseif ($output == "lose")
                    {
                        echo "<h3>You lose!</h3>";

                        $win = 0;
                        $key = "";

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    elseif ($output == "draw")
                    {
                        echo "<h3>Draw.</h3>";
                    }
                    elseif ($output == "cheat")
                    {
                        echo "<h3>Fair game!</h3>";
                        
                        $win = 0;
                        $key = "";

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    else
                    {
                        print_r($output);
                    }
                }
            }
            
            if ($win >= 1000)
            {
                echo "<h3>You win this game 1000 times! Now you may get the <a href='game02.php?oper=reward&value=game02'>reward?</a></h3>";
            }
            else
            {
                echo "<h3>Currently you win: ".$win."/1000, next choice:</h3><br>";
                echo "<a href='game02.php?oper=play&value=S'><img src='/img/02_01.jpg'></a>";
                echo "<a href='game02.php?oper=play&value=T'><img src='/img/02_02.jpg'></a>";
                echo "<a href='game02.php?oper=play&value=R'><img src='/img/02_03.jpg'</a>";
                echo "<a href='game02.php?oper=play&value=W'><img src='/img/02_04.jpg'</a>";
            }
        ?>
        <br/>
    </center>
</body>
</html>