<html>
<body>
    <style>
        img
        {
            width: 120px;
            height: 120px;
        }
    </style>

    <center>
        <h2>Welcome to game05: Elephant-Cat-Mouse!</h2><h3>(Elephant Win Cat, Cat Win Mouse, Mouse Win Elephant)</h3><br><br>

        <?php
            error_reporting(0);

            function safe_str($string) 
            {
                return preg_replace("/[^\w]/", "", $string);
            }

            $win = 0;
            if (isset($_COOKIE["win"]))
            {
                $win = safe_str($_COOKIE["win"]);
            }

            if (isset($_GET["oper"]) and isset($_GET["value"]))
            {
                $oper = safe_str($_GET["oper"]);
                $value = safe_str($_GET["value"]);

                $white_str = array("E", "C", "M", "game01", "game02", "game03", "game04", "game05");
                if (($oper == "play" or $oper = "reward") and in_array($value, $white_str))
                {
                    $ch = curl_init();
                    $url = "http://127.0.0.1:8080/cgi-bin/game05.cgi?oper=".$oper."&value=".$value;
                    
                    $cookie = "win=".$win.";";
                    $key = "";
                    if (isset($_COOKIE["key"]))
                    {
                        $key = safe_str($_COOKIE["key"]);
                        $cookie = $cookie."key=".$key;
                    }

                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    $output = curl_exec($ch);
                    curl_close($ch);

                    if ($output == "win")
                    {
                        echo "<h3>You win this one!</h3>";

                        $win = $win + 1;
                        $key = md5($key.$_GET["value"]);

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    elseif ($output == "lose")
                    {
                        echo "<h3>You lose!</h3>";

                        $win = 0;
                        $key = "";

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    elseif ($output == "draw")
                    {
                        echo "<h3>Draw.</h3>";
                    }
                    elseif ($output == "cheat")
                    {
                        echo "<h3>Fair game!</h3>";
                        
                        $win = 0;
                        $key = "";

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    else
                    {
                        print_r($output);
                    }
                }
            }
            
            if ($win >= 1000)
            {
                echo "<h3>You win this game 1000 times! Now you may get the <a href='game05.php?oper=reward&value=game05'>reward?</a></h3>";
            }
            else
            {
                echo "<h3>Currently you win: ".$win."/1000, next choice:</h3><br>";
                echo "<a href='game05.php?oper=play&value=E'><img src='/img/05_01.jpg'></a>"."    ";
                echo "<a href='game05.php?oper=play&value=C'><img src='/img/05_02.jpg'></a>"."    ";
                echo "<a href='game05.php?oper=play&value=M'><img src='/img/05_03.jpg'</a>";
            }
        ?>
        <br/>
    </center>
</body>
</html>