<html>
<body>
    <style>
        img
        {
            width: 150px;
            height: 200px;
        }
    </style>

    <center>
        <h2>Welcome to game04: Emperor-Citizen-Slave!</h2><h3>(Emperor Win Citizen, Citizen Win Slave, Slave Win Emperor)</h3><br><br>

        <?php
            error_reporting(0);

            function safe_str($string) 
            {
                return preg_replace("/[^\w\-\%]/", "", $string);
            }

            $win = 0;
            if (isset($_COOKIE["win"]))
            {
                $win = safe_str($_COOKIE["win"]);
            }

            if (isset($_GET["oper"]) and isset($_GET["value"]))
            {
                $oper = safe_str($_GET["oper"]);
                $value = safe_str($_GET["value"]);

                $white_str = array("E", "C", "S");
                if (($oper == "play" and in_array($value, $white_str)) or $oper == "reward")
                {
                    $ch = curl_init();
                    $url = "http://127.0.0.1:8080/cgi-bin/game04.cgi?oper=".$oper."&value=".$value;
                    
                    $cookie = "win=".$win.";";
                    $key = "";
                    if (isset($_COOKIE["key"]))
                    {
                        $key = safe_str($_COOKIE["key"]);
                        $cookie = $cookie."key=".$key;
                    }

                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    $output = curl_exec($ch);
                    curl_close($ch);

                    if ($output == "win")
                    {
                        echo "<h3>You win this one!</h3>";

                        $win = $win + 1;
                        $key = md5($key.$_GET["value"]);

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    elseif ($output == "lose")
                    {
                        echo "<h3>You lose!</h3>";

                        $win = 0;
                        $key = "";

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    elseif ($output == "draw")
                    {
                        echo "<h3>Draw.</h3>";
                    }
                    elseif ($output == "cheat")
                    {
                        echo "<h3>Fair game!</h3>";
                        
                        $win = 0;
                        $key = "";

                        setcookie("win", $win);
                        setcookie("key", $key);
                    }
                    else
                    {
                        print_r($output);
                    }
                }
            }
            
            if ($win >= 1000)
            {
                echo "<h3>You win this game 1000 times! Now you may get the <a href='game04.php?oper=reward&value=%253fdebug%253d1'>reward?</a></h3>";
            }
            else
            {
                echo "<h3>Currently you win: ".$win."/1000, next choice:</h3><br>";
                echo "<a href='game04.php?oper=play&value=E'><img src='/img/04_01.jpg'></a>"." ";
                echo "<a href='game04.php?oper=play&value=C'><img src='/img/04_02.jpg'></a>"." ";
                echo "<a href='game04.php?oper=play&value=S'><img src='/img/04_03.jpg'</a>";
            }
        ?>
        <br/>
    </center>
</body>
</html>