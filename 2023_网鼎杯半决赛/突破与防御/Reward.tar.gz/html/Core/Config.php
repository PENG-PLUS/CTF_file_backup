<?php
//禁止文件直接被访问
if (!defined('ROOT')) {
    header('HTTP/1.1 404 Not Found', true, 404);
    die();
}

//系统识别码
define('SYS_RANDOM_KEY','6687EA622656C419888DEEAEE68199D0');

//数据库配置信息
return array (
  'hostname' => '127.0.0.1',
  'hostport' => '3306',
  'database' => 'dashang',
  'username' => 'root',
  'password' => 'root',
  'type' => 'mysql',
);
