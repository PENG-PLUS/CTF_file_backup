from secret import flag1,flag2,m,c
import hashlib

def lfsr(R,mask):
    output = (R << 1) & 0xffffffff
    i=(R&mask)&0xffffffff
    lastbit=0
    while i!=0:
        lastbit^=(i&1)
        i=i>>1
    output^=lastbit 
    return (output,lastbit)

def lcg(m,c):
    seed = 6473702802409947663
    list = []
    for i in range(10):
        c = (c + m*seed) % flag2
        list.append(c)
        seed = c
    print(list)

R=int(flag1,16)
mask = 0b10100100000010000000100010010100

f=open("key.txt","w")
for i in range(100):
    tmp=0
    for j in range(8):
        (R,out)=lfsr(R,mask)
        tmp=(tmp << 1)^out
    f.write(str(bin(tmp)))
f.close()

lcg(m,c)

flag = flag1 + str(flag2)
flag = hashlib.md5(flag.encode("utf-8")).hexdigest()

'''
[7762911616316678361, 8778349545254661087, 2182563361653435704, 1383751637647655272, 4512576578889812021, 4322633144718249958, 3959701111371594748, 7676663421477866678, 5009230933212388616, 3780469426700690705]
'''