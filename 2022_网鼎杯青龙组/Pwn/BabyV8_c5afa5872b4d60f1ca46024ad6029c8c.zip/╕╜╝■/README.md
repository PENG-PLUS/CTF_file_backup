
* 有一部分diff被黑客删掉了 请你运用你所学的知识  找到这一被删除的diff
```
get reset --hard efd30caf9ae31f8256b99218d0a46892c5017700 
gclient sync
git apply xxx.diff
tools/dev/gm.py x64.release
```

题目环境:20.04
