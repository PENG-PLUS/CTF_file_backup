#!/bin/sh

qemu-system-aarch64 \
	-machine virt -cpu cortex-a53 -smp 1 -m 512M \
	-kernel ./Image \
	-append "console=ttyAMA0 panic=1 quiet" \
	-initrd ./fs.cpio.gz \
	-nographic