Make sure you have **qemu-system-aarch64** installed, then run `run.sh` to start the game.

Good luck!