import tenseal as ts
from Crypto.Util.number import *
from Crypto.Util.Padding import pad
from gmpy2 import *
from Crypto.Util.strxor import strxor
import random

my_key = b'xxx'
# part1
def gen_keys(k):
    p, q, r = getPrime(k), getPrime(k), getPrime(k)
    pubkey = p**2 * q * r
    n = pubkey
    phi = (p-1) * (q-1) * (r-1)
    privkey = inverse(n, phi)
    return pubkey, privkey

def encrypt_my_key(my_key, pubkey):
    return pow(bytes_to_long(pad(my_key,190)), pubkey, pubkey)

# part2
context = ts.context(
            ts.SCHEME_TYPE.CKKS,
            poly_modulus_degree=8192,
            coeff_mod_bit_sizes=[60, 40, 40, 60])

context.generate_galois_keys()
context.global_scale = 2**40

seal_key = context.serialize(save_public_key=True,
                         save_secret_key=True,
                         save_relin_keys=True,
                         save_galois_keys=True)

table = ['x','y','z','r','s','t','p','q','g']
def CKKS_vector_cal(formula,*vec):

    vec = list(vec)
    if len(vec) != 9:
        for i in range(9-len(vec)):
            vec.append([0])
    x,y,z,r,s,t,p,q,g = vec
    # 如果传入了矩阵无法加密，则直接抛出异常再pass，这样可保留其为明文形式
    try:
        x = ts.ckks_vector(context, x)
        y = ts.ckks_vector(context, y)
        z = ts.ckks_vector(context, z)
        r = ts.ckks_vector(context, r)
        s = ts.ckks_vector(context, s)
        t = ts.ckks_vector(context, t)
        p = ts.ckks_vector(context, p)
        q = ts.ckks_vector(context, q)
        g = ts.ckks_vector(context, g)
    except:
        pass
    result = eval(formula)
    return result.serialize()

pub,pri = gen_keys(512)
enc_my_key = encrypt_my_key(my_key,pub)

f1 = open('SEAL_flags.txt','rb')
flags = f1.readlines()

for i in range(len(flags)):
    print(i)
    flag = flags[i].strip()
    print(flag)
    enc_flag = strxor(flag,my_key)
    enc_flag_ = [i for i in enc_flag]
    M = []
    for j in range(len(flag)):
        tmp = []
        for j in range(len(flag)):
            tmp.append(random.randint(2 ** 30, 2 ** 32))
        M.append(tmp)

    e = [random.randint(2 ** 20, 2 ** 20) for _ in range(len(flag))]
    r = CKKS_vector_cal('x.matmul(y)+z', enc_flag_, M, e)
    para = open(f'parameter{i}.txt','w')
    para.write(f'pub = {pub}\n')
    para.write(f'pri = {pri}\n')
    para.write(f'enc_my_key = {enc_my_key}\n')
    para.write(f'M = {M}')

    sealkey = open(f'keys{i}','wb')
    sealkey.write(seal_key)
    cipher = open(f'enc{i}', 'wb')
    cipher.write(r)