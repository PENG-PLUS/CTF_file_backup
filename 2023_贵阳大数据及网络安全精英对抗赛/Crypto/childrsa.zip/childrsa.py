from Crypto.Util.number import *

flag = b'xxx'
p = getPrime(512)
q = getPrime(512)
n = p * q
P = getPrime(1024)
Q = getPrime(1024)
N = P * Q
e = 65537
gift = (P+Q) >> 400

hint = (p & ((1 << 350) - 1)) >> 5
enc_hint = pow(hint,e,N)
c = pow(bytes_to_long(flag),e,n)
f = open(f'out{i+1}.txt','w')
f.write(f'N = {N}\n')
f.write(f'n = {n}\n')
f.write(f'gift = {gift}\n')
f.write(f'enc_hint = {enc_hint}\n')
f.write(f'c = {c}')

