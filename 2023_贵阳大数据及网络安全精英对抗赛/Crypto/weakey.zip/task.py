import hashlib
import struct
from ed25519 import publickey, signature
from binascii import unhexlify
from os import urandom

def change_key(m):
    x = [struct.unpack('<I', m[i:i+4])[0] for i in range(0, len(m), 4)]
    x[1] = (x[1] + (2 ** 31)) % 2**32
    x[2] = (x[2] + ((2 ** 31) - (2 ** 28))) % 2**32
    x[12] = (x[12] - (2 ** 16)) % 2**32
    res = [struct.pack('<I', i) for i in x]
    return b"".join(res)

with open("flag.txt", "r")as f:
    flag = f.read()
sk1 = unhexlify(input("your sk in hex:").strip().encode())
sk2 = change_key(sk1)
pk1 = publickey(sk1)
pk2 = publickey(sk2)
m = bytes([i for i in range(1, 128)])
sig1 = signature(m, sk1, pk1)
sig2 = signature(m, sk2, pk2)
if sig1 == sig2:
    print(flag)
