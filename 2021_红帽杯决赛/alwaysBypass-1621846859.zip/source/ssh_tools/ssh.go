package ssh_tools

import (
	"fmt"
	"golang.org/x/crypto/ssh"
	"log"
	"net"
	"time"
)

func SSHRun(ip, port, username, password string, cmd string) (string, error) {
	fmt.Println("Running on ip " + ip + "...")

	clientConfig := ssh.ClientConfig{
		User: username,
		Auth: []ssh.AuthMethod{ssh.Password(password)},
		HostKeyCallback: func(hostname string, remote net.Addr, key ssh.PublicKey) error {
			return nil
		},
	}
	client, err := ssh.Dial("tcp", ip+":"+port, &clientConfig)
	if err != nil {
		return "服务器登录错误", err
	}

	defer client.Close()

	session, err := client.NewSession()
	if err != nil {
		log.Print(ip + ":创建session错误： " + err.Error())
	}
	defer session.Close()

	output, err := session.Output(cmd)
	if err != nil {
		return err.Error(), err
	}
	time.Sleep(time.Second * 1)

	return string(output), nil
}
