package main

import (
	"alwaysBypass/ssh_tools"
	"alwaysBypass/user"
	"github.com/gin-gonic/gin"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

var FLAG string = "flag{test_flag}"

func main() {

	r := gin.Default()

	r.LoadHTMLGlob("html/*")
	r.StaticFS("/static", http.Dir("./static"))

	r.GET("/images", func(c *gin.Context) {
		if strings.Contains(c.Request.RequestURI, "../") {
			c.String(http.StatusOK, "Illegal input")
		} else {
			images := c.DefaultQuery("file", "images.jpeg")
			images = strings.ReplaceAll(images, "../", "")
			fpath := filepath.Join("images", images)
			if stat, err := os.Stat(fpath);err ==nil && stat.Size()<13448304 {
				c.File(filepath.Join("images", images))
			}
		}

	})

	r.POST("/identity", func(c *gin.Context) {
		username := c.PostForm("username")
		identity := c.PostForm("identity")
		if username != "" && identity != "" {
			token, err := user.GenerateToken(username, identity)
			if err != nil {

				c.HTML(http.StatusOK,"location.tmpl",gin.H{
					"notice":err.Error(),
					"href":"/",
				})

			} else {
				c.SetCookie("token", token, 3600, "/", "", false, true)
				c.HTML(http.StatusOK,"location.tmpl",gin.H{
					"href":"/exec",
				})

			}

		} else {
			c.HTML(http.StatusOK,"location.tmpl",gin.H{
				"notice":"Can't pass the empty parameters;",
				"href":"/",
			})

		}
	})

	r.GET("/", func(c *gin.Context) {
		c.HTML(http.StatusOK, "index.tmpl", gin.H{
		})
	})

	r.GET("/exec", func(c *gin.Context) {
		c.HTML(http.StatusOK, "exec.tmpl", gin.H{
		})
	})

	r.POST("/exec", func(c *gin.Context) {
		command := c.PostForm("command")
		token, err := c.Cookie("token")
		if err != nil {
			c.HTML(http.StatusOK,"location.tmpl",gin.H{
				"notice":"alert('identity')",
				"href":"/",
			})
			return
		}
		token =strings.TrimPrefix(token, "bearer ")
		if ok ,err := user.TokenIsAdmin(token); err == nil && ok {
			res, err := ssh_tools.SSHRun("127.0.0.1", "22", "root", FLAG, command)
			if err != nil {
				c.HTML(http.StatusOK,"location.tmpl",gin.H{
					"notice":"error",
					"href":"/",
				})
			} else {
				c.HTML(http.StatusOK,"location.tmpl",gin.H{
					"notice":res,
					"href":"/exec",
				})

			}
		}else {
			c.HTML(http.StatusOK,"location.tmpl",gin.H{
				"notice":"The administrator has the authority to do this, you can’t",
				"href":"/",
			})
		}

	})

	r.Run(":8081")
}
