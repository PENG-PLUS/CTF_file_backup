package user

import (
	"fmt"
	"github.com/dgrijalva/jwt-go"
	"github.com/joho/godotenv"
	"io/ioutil"
	"math/rand"
	"os"
	"time"
)

type MyCustomClaims struct {
	ID int `json:"id"`
	jwt.MapClaims
}

var AdminKey string

func init() {
	if err := godotenv.Load(); err != nil {
		fmt.Print("No .env file found")
	}

	rand.Seed(time.Now().UnixNano())

	f, err := ioutil.ReadFile("/this_is_a_very_long_key_because_I_dont_want_you_read_it")
	if err != nil {
		fmt.Println("read fail", err)
	}

	AdminKey = string(f)


}

var SecretString, _ = os.LookupEnv("SECRET_KEY")
var Secret = []byte(SecretString)


func GenerateToken(username string, identity string) (string, error) {

	claims := MyCustomClaims{
		10086,
		jwt.MapClaims{
			"aud":      identity,
			"username": username,
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	ss, err := token.SignedString(Secret)
	return ss, err

}

func TokenIsAdmin(ss string) (bool, error) {

	token, err := jwt.ParseWithClaims(ss, &MyCustomClaims{}, func(token *jwt.Token) (interface{}, error) {
		return Secret, nil
	})
	if err != nil {
		return false, err
	}
	if claims, ok := token.Claims.(*MyCustomClaims); ok && token.Valid {
		if aud, ok := claims.MapClaims["aud"].(string); ok && aud == "" {
			return false, nil
		}
		if claims.ID != 10086 && claims.VerifyAudience(AdminKey, false) {
			return true, nil
		}
	}

	return false, nil
}
