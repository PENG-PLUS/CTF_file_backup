#!/bin/bash

service ssh start

export GIN_MODE=release

FLAG=flag{test_flag}
echo root:$FLAG|chpasswd

cd /web && ./web > /dev/null 2>&1 &

tail -f /dev/null
