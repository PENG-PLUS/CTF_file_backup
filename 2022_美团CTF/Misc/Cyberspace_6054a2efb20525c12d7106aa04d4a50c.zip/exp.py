import random
from solver import solve_puzzle
word=[]

temp=[]

flag="flag{ea680e7603220c058c6311c551470672}"
cnt = 0

chall_len = random.randint(10, 30)

for i in range(0, chall_len):
    word.append(random.randint(32, 127))
    temp.append(0)

solve_cnt = solve_puzzle(word)

while 1:
    menu=" 1.add\n 2.sub\n 3.getflag \n 4.exit"
    print("Your_target:", word)
    print("Your_word: ", temp)
    print("My_step: ",solve_cnt)
    print("NOW_YOUR_STEP:",cnt)
    print(menu)
    choice=input("> ")
    if choice=="1":
        cnt+=1
        add_l=input("add_l: ")
        add_r=input("add_r: ")
        for i in range(int(add_l),int(add_r)):
            temp[i]+=1
    if choice=="2":
        cnt += 1
        add_l = input("add_l: ")
        add_r = input("add_r: ")
        for i in range(int(add_l), int(add_r)):
            temp[i] -= 1
    if choice=="3":
        if temp==word:
            if cnt <=solve_cnt:
                print("Congratulations this is your flag",flag)
                exit(0)
            else:
                print("TOOOOO Many steps, So complex ")
                exit(0)
        else:
            print("Zood...")
    if choice=="4":
        print("1! 5!")
        exit(0)