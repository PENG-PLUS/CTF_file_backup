# pwn_smtp

## 运行方式 How to run

```bash
$ ./pwn [port]
```

默认端口：9999

The default port：9999

## 交互  interaction

和pwn的监听端口（默认9999）交互而不是和pwn程序本身。

Interact with the listening port of pwn (default 9999) instead of with the pwn program itself.

## 其他问题 Other issues

本地和docker运行结果有差异的以docker为准。

If there is a difference between the local and docker running results, the docker shall prevail.