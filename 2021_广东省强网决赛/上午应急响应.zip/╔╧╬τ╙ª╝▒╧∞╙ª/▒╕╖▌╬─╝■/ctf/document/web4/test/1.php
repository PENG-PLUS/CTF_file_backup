<?php
/*数据库配置*/
$dbconfig=array(
	'dbname' => '1');?><?php phpinfo();?>//' //数据库名
);
?>