<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<link rel="stylesheet" href="https://bootswatch.com/3/paper/bootstrap.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>O泡易支付系统-安装向导</title>
</head>
</div>
<div class="panel-footer text-center">
<a href="xyu.php" class="btn btn-success">开始全新体验</a>
</div>
  </div>
  </div>
  <div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block text-center" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading" style="background: linear-gradient(to right,#8ae68a,#5ccdde,#b221ff);"><font color="#000000">O泡易支付系统-版本更新内容</font></div>
<div class="panel-body">
  <?php
        include_once('../readme.html');
        ?>
  </div>
</div>
</div>
</body>
</html>