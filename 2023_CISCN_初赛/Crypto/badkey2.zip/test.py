from Crypto.Util.number import *
from Crypto.PublicKey import RSA
from hashlib import sha256
import random, os, signal, string

e = 65537
p = getPrime(512)
while p % e == 1:
    p = getPrime(512)

def proof_of_work():
    random.seed(os.urandom(8))
    proof = ''.join([random.choice(string.ascii_letters+string.digits) for _ in range(20)])
    _hexdigest = sha256(proof.encode()).hexdigest()
    print(f"sha256(XXXX+{proof[4:]}) == {_hexdigest}")
    print('Give me XXXX: ')
    x = input()
    if len(x) != 4 or sha256(x.encode()+proof[4:].encode()).hexdigest() != _hexdigest:
        print('Wrong PoW')
        return False
    return True

if not proof_of_work():
    exit(1)
    
signal.alarm(10)
print("Give me 10 bad RSA keypairs that have the same prime factor:", p)

used_n = []
for i in range(10):
    try:
        n = int(input('n = '))
        assert n % p == 0
        assert n not in used_n
        used_n.append(n)
        q = n // p
        assert q > 0
        assert q != p
        assert q.bit_length() == 512
        assert isPrime(q)
        assert q % e != 1
        d = inverse(e, (p-1)*(q-1))
    except:
        print("Invalid n")
        exit(2)

    try:
        key = RSA.construct([n,e,d])
        print("This is not a bad RSA keypair,")
        exit(3)
    except KeyboardInterrupt:
        print("Hacker detected.")
        exit(4)
    except ValueError:
        print("Good job!")

print("How could this happen?")
from secret import flag
print(flag)
