from Crypto.Util.number import *
from flag import flag
from random import randint, seed
from sage.all_cmdline import *
from os import urandom

def padding(data, length):
    return data + ((length - (len(data) % length)) * chr((length - (len(data) % length)) & 0xff)).encode()

BITS = 512
msg = ZZ(bytes_to_long(padding(flag, BITS//8)))

while True:
    n = getStrongPrime(BITS)
    if n > msg:
        break

N = Zmod(n) # print

def f(x, p):
    return [x, x + p, x + 2*p, x + 3*p]

def gen():
    while True:
        p = randint(2,16)
        q = randint(2,16)
        if p != q:
            break
    x = randint(2, 16)
    a = f(x, p)
    y = randint(2, 16)
    b = f(y, q)
    p1 = [getPrime(64),getPrime(64),getPrime(64),getPrime(64)]
    p0 = [getPrime(64),getPrime(64),getPrime(64),getPrime(64)]

    return a, b, p1, p0


def Linear_Recurrence(a, b, p1, p0):
    def one_round(p0, p1):
        return vector([a * p0 - b * p1, p0])

    def Iteration(msg):
        Ns = N['p0, p1']
        (p0, p1) = Ns._first_ngens(2)
        if msg == 0: 
            return vector([p0, p1])

        half = Iteration(msg // 2)
        full = half(*half)
        if msg % 2 == 0: 
            return full
        else: 
            return one_round(*full)

    return Iteration(msg)[0](p1, p0)


a, b, p1, p0 = gen()  # print
result = [
    Linear_Recurrence(a[0], b[0], p1[0], p0[0]),
    Linear_Recurrence(a[1], b[1], p1[1], p0[1]),
    Linear_Recurrence(a[2], b[2], p1[2], p0[2]),
    Linear_Recurrence(a[3], b[3], p1[3], p0[3])
]  # print