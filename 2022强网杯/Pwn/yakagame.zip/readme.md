you can upload your exp code and when you think your exp code is good,just attack it

'''bash
opt-8 -load ./yaka.so -ayaka ./exp.ll
'''

will execte