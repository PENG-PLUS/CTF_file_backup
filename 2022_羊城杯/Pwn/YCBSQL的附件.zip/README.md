# YCBSQL

**[+]Welcome to YCB!**



sql文件提交后，后台会以类似如下的方式执行：

```c
system("./sqlite3 < ./exp.sql")
```



**points:**

- 远端反弹shell可能面临不稳定，可以尝试用`nc`来外带flag，flag的路径为`/flag`
- 如果需要堆喷来解，请尽量选取堆喷区域中靠后一些的地址以增加成功率