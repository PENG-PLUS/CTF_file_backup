import socketserver
from time import sleep
from secret import flag
import signal
import random 

from Crypto.Util.number import *
import random

def pow_d(g, e, n):
	t, r = 0, 1
	for _ in bin(e)[2:]:
		if r == 4: t += 1
		r = pow(r, 2, n)
		if _ == '1': r = r * g % n
	return t, r

def ts(m, p):
	m = m % p
	return pow(m, (p - 1) // 2, p) == 1
class Task(socketserver.BaseRequestHandler):
    def _recvall(self):
        BUFF_SIZE = 2048
        data = b''
        while True:
            part = self.request.recv(BUFF_SIZE)
            data += part
            if len(part) < BUFF_SIZE:
                break
        return data.strip()

    def send(self, msg, newline=True):
        try:
            if newline:
                msg += b'\n'
            self.request.sendall(msg)
        except:
            pass

    def recv(self):
        return self._recvall()
        



    def handle(self):
        border = b"|"
        self.send(border*72)
        self.send(border+b"Solve a DLP challenge in some special way to get the flag", border)

        p = 2 ** 1024 - 2 ** 234 - 2 ** 267 - 2 ** 291 - 2 ** 403 - 1
        s = random.randint(2, (p - 1) // 2)

        while True:
            self.send(b"| Options: \n|\t[T]ry the magic machine \n|\t[Q]uit")
            ans = self.recv().lower()

            if ans == b't':
                self.send(border+b"please send your desired integer: ")
                g = self.recv()
                try:
                    g = int(g)
                except:
                    self.send(border+b"The given input is not integer!")
                    break 
                sleep(0.3)
                if ts(g, p):
                    t, r = pow_d(g, s, p)
                    if r == 4:
                        self.send(border+b'Great! you got the flag:'+flag)
                    else:
                        self.send(border+b"t, r = "+f"{t, r}".encode())
                else:
                    self.send(border+"The given base is NOT valid!!!")
            elif ans == b'q':
                self.send(border+"Quitting ...")
                break 
            else:
                self.send(border+"Bye bye ...") 
                break 
                
                






class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass


class ForkedServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    pass


if __name__ == "__main__":
    HOST, PORT = '0.0.0.0', 10001
    server = ForkedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    print(HOST, PORT)
    server.serve_forever()