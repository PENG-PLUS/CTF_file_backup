import random
import string
import subprocess

WELCOME = '''
                     _______   _____     ___   __    _____       _      _ _______   
              ____  |__   __| |  __ \   / _ \ / _|  / ____|     | |    (_)__   __|  
  _ __ ___   / __ \ ___| | ___| |__) | | | | | |_  | (___   __ _| |     _   | | ___ 
 | '_ ` _ \ / / _` / __| |/ _ \  _  /  | | | |  _|  \___ \ / _` | |    | |  | |/ _ \
 | | | | | | | (_| \__ \ |  __/ | \ \  | |_| | |    ____) | (_| | |____| |  | |  __/
 |_| |_| |_|\ \__,_|___/_|\___|_|  \_\  \___/|_|   |_____/ \__, |______|_|  |_|\___|
             \____/                                           | |                   
                                                              |_|                   
'''

print(WELCOME)

def name_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

tmp_dbpath = f'/tmp/{name_generator()}.db'

query_idea = input("Input your Query command --->> ")

black_list = ['.', 'lo', ';']

for y in black_list:
    if y in query_idea:
        print("Hacker! Banned...")
        exit()

sqlite3_process = subprocess.Popen(["sqlite3", tmp_dbpath, query_idea], stdout=subprocess.PIPE)
(output, error) = sqlite3_process.communicate()
#Show your output!
print(output.decode())
