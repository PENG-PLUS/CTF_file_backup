import os
import subprocess
import base64
import binascii
import zipfile


BANNER = """
   _____      /\/|        /\/|              _____ _    ___       ______ 
  / ____|    |/\/ |      |/\/              / ____| |  / _ \     |  ____|
 | (___   __ _  | | ____ _   _ __   __ _  | (___ | |_| | | |_ __| |__   
  \___ \ / _` | | |/ / _` | | '_ \ / _` |  \___ \| __| | | | '__|  __|  
  ____) | (_| | |   < (_| | | | | | (_| |  ____) | |_| |_| | |  | |____ 
 |_____/ \__,_| |_|\_\__,_| |_| |_|\__,_| |_____/ \__|\___/|_|  |______|
                                                                                                                   
"""
SAKANA_PATH = "./sakana"


def welcome_menu():
    print()
    print("1. Upload an sakana")
    print("2. Download an sakana")
    print("3. Delete an sakana")
    print("4. Upload sakanas of Zip")
    print("5. Exit")
    print()
    print("Input your choice")
    try:
        return int(input(">> "))
    except ValueError:
        return -1


def sakana_upload():
    sakana_file_name = input("Name for your sakana:")

    encoded_sakana_content = input("Base64-encoded sakana:")
    try:
        decode_content = base64.b64decode(encoded_sakana_content)
    except binascii.Error:
        print("Error base64!")
        return

    if decode_content == b"":
        print("Empty file!")
        return

    if not decode_content.startswith(b"sakana"):
        print("Only sakana files are allowed!")
        return

    with open(os.path.join(SAKANA_PATH, sakana_file_name), "wb") as sakana_file_handle:
        sakana_file_handle.write(decode_content)


def sakana_download():
    sakana_file = os.listdir(SAKANA_PATH)

    for file_num, file_name in enumerate(sakana_file):
        print(f"{file_num} -> {file_name}")
    print()

    print("Select num which sakana to download")
    try:
        sakana_num = int(input(">> "))
        sakana_path = os.path.join(SAKANA_PATH, sakana_file[sakana_num])
    except:
        print("Invalid num of sakana!")
        return

    with open(sakana_path, "rb") as sakana_file_handle:
        sakana = sakana_file_handle.read()

    print("Here is your sakana file(base64ed)")
    print(base64.b64encode(sakana).decode())


def sakana_delete():
    sakana_file = os.listdir(SAKANA_PATH)

    for file_num, file_name in enumerate(sakana_file):
        print(f"{file_num} -> {file_name}")
    print()

    print("Select num which sakana to delete")
    try:
        sakana_num = int(input(">> "))
        sakana_path = os.path.join(SAKANA_PATH, sakana_file[sakana_num])
    except:
        print("Invalid num of sakana!")
        return

    os.remove(sakana_path)
    print("sakana file successfully deleted!")


def sakana_upload_sakanas():
    sakanas_path = "/tmp/sakanas.zip"

    encoded_zip_content = input("Base64-encoded zip of sakanas:")
    try:
        with open(sakanas_path, "wb+") as zip_file:
            zip_content = base64.b64decode(encoded_zip_content)
            zip_file.write(zip_content)

            #no symlink for it 
            for zip_info in zipfile.ZipFile(zip_file).infolist():
                if zip_info.external_attr >> 16:
                    print("Hacker!!!")
                    return
    except zipfile.BadZipFile:
        print("Error zipfile!")
        return
    except binascii.Error:
        print("Error base64!")

    if subprocess.run(["unzip", "-o", "-q", sakanas_path, "-d", SAKANA_PATH]).returncode <= 1:
        print("Zip successfully uploaded and extracted")
    else:
        print("Error while extracting the Zip")


def main():
    os.makedirs(SAKANA_PATH, exist_ok=True)

    print(BANNER)
    while True:
        choice = welcome_menu()

        if choice == 1:
            sakana_upload()
        elif choice == 2:
            sakana_download()
        elif choice == 3:
            sakana_delete()
        elif choice == 4:
            sakana_upload_sakanas()
        elif choice == 5:
            print("bye......")
            break
        else:
            print("Invalid choice!")


if __name__ == "__main__":
    main()